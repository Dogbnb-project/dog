from django.apps import AppConfig


class DogConfig(AppConfig):
    name = 'dog'
